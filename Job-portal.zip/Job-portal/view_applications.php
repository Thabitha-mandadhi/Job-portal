<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'poster') {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['user'];

// Get poster ID
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$poster = $result->fetch_assoc();
$poster_id = $poster['id'];

// Fetch job applications for jobs posted by this poster
$stmt = $conn->prepare("
    SELECT applications.id AS app_id, applications.status, applications.applied_date, 
           users.email AS seeker_email, users.resume, 
           jobs.title 
    FROM applications
    JOIN jobs ON applications.job_id = jobs.id
    JOIN users ON applications.user_id = users.id
    WHERE jobs.poster_id = ?
    ORDER BY applications.applied_date DESC
");
$stmt->bind_param("i", $poster_id);
$stmt->execute();
$applications = $stmt->get_result();

echo "<h2>Job Applications</h2>";

if ($applications->num_rows > 0) {
    while ($row = $applications->fetch_assoc()) {
        echo "<div style='border:1px solid #ccc; padding:10px; margin:10px;'>";
        echo "<p><strong>Job Title:</strong> " . htmlspecialchars($row['title']) . "</p>";
        echo "<p><strong>Seeker Email:</strong> " . htmlspecialchars($row['seeker_email']) . "</p>";
        echo "<p><strong>Status:</strong> " . htmlspecialchars($row['status']) . "</p>";
        echo "<p><strong>Applied Date:</strong> " . htmlspecialchars($row['applied_date']) . "</p>";

        // Show resume link if available
        if (!empty($row['resume'])) {
            echo "<p><strong>Resume:</strong> <a href='" . htmlspecialchars($row['resume']) . "' target='_blank'>View Resume</a></p>";
        } else {
            echo "<p><strong>Resume:</strong> Not uploaded</p>";
        }

        echo "<form method='post' action='update_application_status.php' style='margin-top:10px;'>
                <input type='hidden' name='application_id' value='" . $row['app_id'] . "'>
                <select name='status'>
    <option value='Pending'" . ($row['status'] === 'Pending' ? ' selected' : '') . ">Pending</option>
    <option value='Accepted'" . ($row['status'] === 'Accepted' ? ' selected' : '') . ">Accepted</option>
    <option value='Rejected'" . ($row['status'] === 'Rejected' ? ' selected' : '') . ">Rejected</option>
</select>
                <input type='submit' value='Update'>
              </form>";

        echo "<form method='post' action='delete_application.php' onsubmit='return confirm(\"Are you sure?\");'>
                <input type='hidden' name='application_id' value='" . $row['app_id'] . "'>
                <input type='submit' value='Delete'>
              </form>";
        echo "</div>";
    }
} else {
    echo "<p>No applications found for your jobs.</p>";
}
?>
