# Job Portal Project

## 📝 Description
A simple PHP-based Job Portal where users can register as Job Seekers or Job Posters. Seekers can apply for jobs, and Posters can manage job postings and applications.

## 📁 Folder Structure
- `Job-portal/
│
├── db.php                         ← Database connection file
├── index.php                      ← Landing page
├── register.php                   ← User registration (Seeker/Poster)
├── login.php                      ← Login page
├── logout.php                     ← Logout and destroy session
│
├── post_job.php                   ← Form to post job (for Posters)
├── post_job_process.php           ← Handles job posting form submission
│
├── job_listings.php               ← Lists all jobs (for Seekers)
├── apply_job.php                  ← Applies to a job (Seeker action)
│
├── my_applications.php            ← Seekers view application status
├── view_applications.php          ← Posters view who applied to their jobs
├── update_application_status.php  ← Poster accepts/rejects applications
│
├── dashboard/
│   ├── seeker.php                 ← Seeker Dashboard
│   └── poster.php                 ← Poster Dashboard
│
├── uploads/                       ← Folder where resumes are stored
│
└── README.md                      ← Project documentation (your guide!)

## 🛠 Setup Instructions
1. Import `job-portal.sql` into your phpMyAdmin.
2. Copy the project folder to `htdocs`.
3. Run `http://localhost/Job-portal/` in your browser.

## 👩‍💻 Credentials for Testing
- Job Seeker: `thabitha909@gmail.com` / password:123
- Job Poster: `jonah@gmail.com` / password:1234
- Job Seeker: `clarie@gmail.com` / password:C128
- Job Poster: `gloria@gmail.com` / password:Thabi@12

## 📦 Submission
GitHub and ZIP folder upload
