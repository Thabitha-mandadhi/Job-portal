<?php
session_start();
include '../db.php'; // Adjust path since you're inside Dashboard folder

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'seeker') {
    header("Location: ../login.php");
    exit();
}

$user_email = $_SESSION['user'];
$role = $_SESSION['role'];

// Fetch username and resume path
$stmt = $conn->prepare("SELECT username, resume FROM users WHERE email = ?");
$stmt->bind_param("s", $user_email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user):
    $username = $user['username'];
    $resume = $user['resume'];
?>

<h2>Welcome, <?= htmlspecialchars($username) ?> (Job Seeker)</h2>
<p>Email: <?= htmlspecialchars($user_email) ?></p>

<?php if (!empty($resume)): 
    $resume_path = trim($resume);
    $full_path = __DIR__ . '/../' . $resume_path;
?>
    <p>Resume: 
        <?php if (file_exists($full_path)): ?>
            <a href="../<?= htmlspecialchars($resume_path) ?>" target="_blank">View Resume</a>
        <?php else: ?>
            <span style="color:red;">File not found!</span>
        <?php endif; ?>
    </p>
<?php else: ?>
    <p>No resume uploaded. <a href="../upload_resume.php">Upload Resume</a></p>
<?php endif; ?>

<p><a href="../job_listings.php">View Available Jobs</a></p>
<p><a href="../my_applications.php">My Applications</a></p>
<p><a href="../logout.php">Logout</a></p>

<?php else: echo "User not found!"; endif; ?>
