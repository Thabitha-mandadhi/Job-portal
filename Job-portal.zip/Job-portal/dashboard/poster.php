<?php
session_start();
include '../db.php'; // <- fixed path

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'poster') {
    header("Location: ../login.php");
    exit();
}

$username = $_SESSION['user'];
$email = $username;
$role = $_SESSION['role'];

echo "<h2>Welcome, " . htmlspecialchars($username) . " (Job Poster)</h2>";
echo "<p>Email: " . htmlspecialchars($email) . "</p>";

echo "<ul>";
echo "<li><a href='../post_job.php'>Post a Job</a></li>";
echo "<li><a href='../view_posted_jobs.php'>Manage Posted Jobs</a></li>";
echo "<li><a href='../view_applications.php'>View Applications</a></li>";
echo "<li><a href='../logout.php'>Logout</a></li>";
echo "</ul>";
?>
