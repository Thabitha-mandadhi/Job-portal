<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <script>
        // Show/hide resume upload based on role
        function toggleResumeField() {
            var role = document.getElementById("role").value;
            var resumeDiv = document.getElementById("resumeDiv");
            resumeDiv.style.display = (role === "seeker") ? "block" : "none";
        }
    </script>
</head>
<body>
    <h2>User Registration</h2>
    <form action="register_process.php" method="POST" enctype="multipart/form-data">
        <label>Username:</label><br>
        <input type="text" name="username" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>

        <label>Password:</label><br>
        <input type="password" name="password" required><br><br>

        <label>Role:</label><br>
        <select name="role" id="role" onchange="toggleResumeField()" required>
            <option value="">Select role</option>
            <option value="seeker">Job Seeker</option>
            <option value="poster">Job Poster</option>
        </select><br><br>

        <div id="resumeDiv" style="display:none;">
            <label>Upload Resume (PDF only):</label><br>
            <input type="file" name="resume" accept=".pdf"><br><br>
        </div>

        <button type="submit">Register</button>
    </form>
</body>
</html>
