<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'poster') {
    header("Location: login.php");
    exit();
}

$user_email = $_SESSION['user'];

// Get poster ID
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $user_email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    die("User not found.");
}

$poster_id = $user['id'];

// Fetch jobs posted by this user
$stmt = $conn->prepare("SELECT * FROM jobs WHERE poster_id = ? ORDER BY posted_date DESC");
$stmt->bind_param("i", $poster_id);
$stmt->execute();
$jobs = $stmt->get_result();

echo "<h2>Your Posted Jobs</h2>";

if ($jobs->num_rows > 0) {
    while ($job = $jobs->fetch_assoc()) {
        echo "<div style='border: 1px solid #ccc; padding: 10px; margin: 10px;'>";
        echo "<h3>" . htmlspecialchars($job['title']) . "</h3>";
        echo "<p><strong>Description:</strong> " . htmlspecialchars($job['description']) . "</p>";
        echo "<p><strong>Salary:</strong> ₹" . htmlspecialchars($job['salary']) . "</p>";
        echo "<p><strong>Duration:</strong> " . htmlspecialchars($job['duration']) . "</p>";
        echo "<p><strong>Shift:</strong> " . htmlspecialchars($job['shift']) . "</p>";
        echo "<p><strong>Location:</strong> " . htmlspecialchars($job['location']) . "</p>";
        echo "<p><strong>Posted Date:</strong> " . htmlspecialchars($job['posted_date']) . "</p>";

        // ✅ Important: make sure the link includes the full URL with job ID
        $edit_link = "update_job.php?id=" . urlencode($job['id']);
        $delete_link = "delete_job.php?id=" . urlencode($job['id']);

        echo "<a href='$edit_link' style='margin-right: 10px;'>Edit</a>";
        echo "<a href='$delete_link' onclick=\"return confirm('Are you sure you want to delete this job?');\">Delete</a>";
        echo "</div>";
    }
} else {
    echo "<p>No jobs found.</p>";
}
?>