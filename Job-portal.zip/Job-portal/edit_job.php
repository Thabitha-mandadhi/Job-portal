<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'poster') {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("Job ID not specified.");
}

$job_id = $_GET['id'];

// Fetch job details
$stmt = $conn->prepare("SELECT * FROM jobs WHERE id = ?");
$stmt->bind_param("i", $job_id);
$stmt->execute();
$result = $stmt->get_result();
$job = $result->fetch_assoc();

if (!$job) {
    die("Job not found.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $salary = $_POST['salary'];
    $experience = $_POST['experience'];
    $shift = $_POST['shift'];
    $location = $_POST['location'];

    $update = $conn->prepare("UPDATE jobs SET title=?, description=?, salary=?, experience=?, shift=?, location=? WHERE id=?");
    $update->bind_param("ssssssi", $title, $description, $salary, $experience, $shift, $location, $job_id);
    $update->execute();

    echo "Job updated successfully! <a href='view_posted_jobs.php'>Back to My Jobs</a>";
    exit();
}
?>

<h2>Edit Job</h2>
<form method="POST">
    <label>Title:</label><br>
    <input type="text" name="title" value="<?= htmlspecialchars($job['title']) ?>" required><br><br>

    <label>Description:</label><br>
    <textarea name="description" required><?= htmlspecialchars($job['description']) ?></textarea><br><br>

    <label>Salary (₹):</label><br>
    <input type="text" name="salary" value="<?= htmlspecialchars($job['salary']) ?>" required><br><br>

    <label>Duration:</label><br>
    <input type="text" name="duration" value="<?= htmlspecialchars($job['duration']) ?>" required><br><br>

    <label>Shift:</label><br>
    <input type="text" name="shift" value="<?= htmlspecialchars($job['shift']) ?>" required><br><br>

    <label>Location:</label><br>
    <input type="text" name="location" value="<?= htmlspecialchars($job['location']) ?>" required><br><br>

    <input type="submit" value="Update Job">
</form>
