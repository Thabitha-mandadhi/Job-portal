<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'poster') {
    die("Only job posters can access this page.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Post a Job</title>
</head>
<body>
    <h2>Post a New Job</h2>
    <form action="post_job_process.php" method="POST">
        <label>Job Title:</label><br>
        <input type="text" name="title" required><br><br>

        <label>Description:</label><br>
        <textarea name="description" required></textarea><br><br>

        <label>Salary:</label><br>
        <input type="number" name="salary" required><br><br>

        <label>Experience:</label><br>
        <input type="text" name="duration" required><br><br>

        <label>Shift:</label><br>
        <input type="text" name="shift" required><br><br>

        <label>Location:</label><br>
        <input type="text" name="location" required><br><br>

        <button type="submit">Post Job</button>
    </form>
</body>
</html>
