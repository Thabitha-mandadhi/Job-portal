<?php
echo "Hello! PHP is working!";
?>