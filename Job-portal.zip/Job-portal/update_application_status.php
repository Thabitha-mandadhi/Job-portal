<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'poster') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['application_id'], $_POST['status'])) {
        $application_id = intval($_POST['application_id']);
        $new_status = $_POST['status'];

        // Only allow valid status values
        $allowed_statuses = ['Pending', 'Accepted', 'Rejected'];

        if (!in_array($new_status, $allowed_statuses)) {
            die("❌ Invalid status option selected.");
        }

        // Update the status in the database
        $stmt = $conn->prepare("UPDATE applications SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $new_status, $application_id);

        if ($stmt->execute()) {
            header("Location: view_applications.php");
            exit();
        } else {
            echo "❌ Failed to update application status.";
        }
    } else {
        echo "❌ Missing application ID or status.";
    }
} else {
    echo "❌ Invalid request method.";
}
?>
