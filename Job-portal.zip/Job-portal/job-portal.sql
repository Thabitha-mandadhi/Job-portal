-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 08, 2025 at 05:15 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `job-portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE `applications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `status` enum('Pending','Accepted','Rejected') DEFAULT 'Pending',
  `applied_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`id`, `user_id`, `job_id`, `status`, `applied_date`) VALUES
(1, NULL, 1, 'Pending', '2025-04-07 04:02:55'),
(2, 9, 1, 'Pending', '2025-04-07 04:06:12'),
(3, 19, 1, 'Pending', '2025-04-07 05:23:55'),
(4, 19, 2, 'Pending', '2025-04-07 05:24:00'),
(6, 19, 8, 'Rejected', '2025-04-07 11:04:58');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `duration` varchar(100) DEFAULT NULL,
  `shift` varchar(50) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `posted_date` date DEFAULT curdate(),
  `poster_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `title`, `description`, `salary`, `duration`, `shift`, `location`, `posted_date`, `poster_id`) VALUES
(1, 'Frontend Developer', 'Build and maintain UI components.', 30000.00, NULL, 'Day', 'Bangalore', '2025-04-07', NULL),
(2, 'Backend Developer', 'Work with APIs and databases.', 35000.00, NULL, 'Night', 'Hyderabad', '2025-04-07', NULL),
(3, 'Full Stack Intern', 'Assist in full stack development tasks.', 15000.00, NULL, 'Day', 'Remote', '2025-04-07', NULL),
(7, 'QA tester', 'Test the quality and accurateness of the work', 120000.00, '3 years', 'morning', 'Gadag', '2025-04-07', 20),
(8, 'Business Analyst', 'Identify business needs, act as bridge between stakeholders and It teams', 120000.00, '2 years', 'morning', 'Mysore', '2025-04-07', 20);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('seeker','poster') NOT NULL,
  `resume` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `resume`) VALUES
(19, 'Thabitha', 'thabitha909@gmail.com', '$2y$10$w0Q7wp2nWhyOt5QFta8Q4OfZOhPTDMJYZowWhXpy0FG3Skn3Eyi3e', 'seeker', 'resumes/1743982167_Thabitha_Mandadhi_FullStackDeveloper_Professionalresume..pdf'),
(20, 'Jonah', 'jonah@gmail.com', '$2y$10$RBIGZv0eZU5u.sMUVa80ku3jltPM3uruUez8UR9U3u0Fh.hwg8iey', 'poster', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_poster` (`poster_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applications`
--
ALTER TABLE `applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `jobs`
--
ALTER TABLE `jobs`
  ADD CONSTRAINT `fk_poster` FOREIGN KEY (`poster_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
