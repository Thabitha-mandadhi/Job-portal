<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'poster') {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("Application ID not provided.");
}

$app_id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM applications WHERE id = ?");
$stmt->bind_param("i", $app_id);
if ($stmt->execute()) {
    header("Location: view_applications.php");
} else {
    echo "Error deleting application.";
}
?>
