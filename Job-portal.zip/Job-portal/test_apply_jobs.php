<?php
session_start();
include 'db.php';

// Simulate a logged-in user (seeker)
$_SESSION['user'] = 'thabitha909@gmail.com';  // Use a real user email from your DB
$_SESSION['role'] = 'seeker';

// Simulate a job ID (make sure this ID exists in the 'jobs' table)
$test_job_id = 1;

echo "<h3>Testing Apply Job...</h3>";
echo "<a href='apply_job.php?job_id=$test_job_id'>Click to Apply for Job ID: $test_job_id</a>";
?>
