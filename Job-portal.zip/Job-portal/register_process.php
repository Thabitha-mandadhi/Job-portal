<?php
include 'db.php';

// Get form data
$username = $_POST['username'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$role = $_POST['role'] ?? '';

// Validate fields
if (empty($username) || empty($email) || empty($password) || empty($role)) {
    die("Please fill all the fields.");
}

// Hash the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Initialize resume variable
$resume_path = null;

// If the user is a job seeker and uploaded a resume
if ($role === 'seeker' && isset($_FILES['resume']) && $_FILES['resume']['error'] === UPLOAD_ERR_OK) {
    $resume_tmp = $_FILES['resume']['tmp_name'];
    $resume_name = basename($_FILES['resume']['name']);
    $target_dir = "resumes/";
    
    // Create directory if not exists
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Generate unique filename
    $resume_path = $target_dir . time() . "_" . $resume_name;
    
    // Move uploaded file
    if (!move_uploaded_file($resume_tmp, $resume_path)) {
        die("Failed to upload resume.");
    }
}

// Insert into database
$stmt = $conn->prepare("INSERT INTO users (username, email, password, role, resume) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $username, $email, $hashed_password, $role, $resume_path);

if ($stmt->execute()) {
    echo "Registered successfully!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
header("Location: login.php");
exit();
?>
