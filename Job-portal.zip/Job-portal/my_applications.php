<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'seeker') {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['user'];

// Get seeker ID
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$seeker_id = $user['id'];

// Fetch applied jobs with status
$query = "
SELECT a.status, a.applied_date, j.title, j.location, j.salary
FROM applications a
JOIN jobs j ON a.job_id = j.id
WHERE a.user_id = ?
ORDER BY a.applied_date DESC
";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $seeker_id);
$stmt->execute();
$applications = $stmt->get_result();

echo "<h2>My Applications</h2>";

if ($applications->num_rows > 0) {
    while ($row = $applications->fetch_assoc()) {
        echo "<div style='border:1px solid #ccc; padding:10px; margin:10px'>";
        echo "<p><strong>Job:</strong> " . htmlspecialchars($row['title']) . "</p>";
        echo "<p><strong>Location:</strong> " . htmlspecialchars($row['location']) . "</p>";
        echo "<p><strong>Salary:</strong> ₹" . htmlspecialchars($row['salary']) . "</p>";
        echo "<p><strong>Applied Date:</strong> " . htmlspecialchars($row['applied_date']) . "</p>";
        echo "<p><strong>Status:</strong> " . htmlspecialchars($row['status']) . "</p>";
        echo "</div>";
    }
} else {
    echo "<p>You have not applied to any jobs.</p>";
}
?>
