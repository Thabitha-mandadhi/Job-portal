<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$user_email = $_SESSION['user'];
$role = $_SESSION['role'];

if ($role !== 'seeker') {
    echo "Only job seekers can view and apply to jobs.";
    exit();
}

// Fetch all job listings
$result = $conn->query("SELECT jobs.*, users.username AS poster_name FROM jobs JOIN users ON jobs.poster_id = users.id ORDER BY posted_date DESC");

echo "<h2>Available Jobs</h2>";
while ($job = $result->fetch_assoc()) {
    echo "<div style='border: 1px solid #ccc; padding: 10px; margin: 10px;'>";
    echo "<h3>" . htmlspecialchars($job['title']) . "</h3>";
    echo "<p><strong>Description:</strong> " . htmlspecialchars($job['description']) . "</p>";
    echo "<p><strong>Salary:</strong> ₹" . htmlspecialchars($job['salary']) . "</p>";
    echo "<p><strong>Duration:</strong> " . htmlspecialchars($job['duration']) . "</p>";
    echo "<p><strong>Shift:</strong> " . htmlspecialchars($job['shift']) . "</p>";
    echo "<p><strong>Location:</strong> " . htmlspecialchars($job['location']) . "</p>";
    echo "<p><strong>Posted By:</strong> " . htmlspecialchars($job['poster_name']) . "</p>";
    echo "<p><strong>Posted Date:</strong> " . htmlspecialchars($job['posted_date']) . "</p>";
    
    echo "<a href='apply_job.php?job_id=" . $job['id'] . "'>Apply</a>";
    echo "</div>";
}
?>
