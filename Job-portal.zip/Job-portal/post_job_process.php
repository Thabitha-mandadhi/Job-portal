<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'poster') {
    die("Unauthorized access.");
}

$title = $_POST['title'];
$description = $_POST['description'];
$salary = $_POST['salary'];
$duration = $_POST['duration'];
$shift = $_POST['shift'];
$location = $_POST['location'];

// Get poster's ID using email
$email = $_SESSION['user'];
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();

if (!$user) {
    die("Poster not found.");
}

$user_id = $user['id'];

$insert = $conn->prepare("INSERT INTO jobs (poster_id, title, description, salary, duration, shift, location, posted_date)
                          VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");

if (!$insert) {
    die("Prepare failed: " . $conn->error);
}

$insert->bind_param("issssss", $user_id, $title, $description, $salary, $duration, $shift, $location);
$insert->execute();

if ($insert->affected_rows > 0) {
    echo "Job posted successfully!";
} else {
    echo "Error posting job.";
}
?>
