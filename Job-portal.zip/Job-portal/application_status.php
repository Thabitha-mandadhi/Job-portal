<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user'])) {
    die("Login to view applications.");
}

$email = $_SESSION['user'];
$user_id_query = $conn->prepare("SELECT id FROM users WHERE email = ?");
$user_id_query->bind_param("s", $email);
$user_id_query->execute();
$user_id_result = $user_id_query->get_result();
$user = $user_id_result->fetch_assoc();
$user_id = $user['id'];

$sql = "SELECT a.status, j.title, j.location, j.posted_date
        FROM applications a
        JOIN jobs j ON a.job_id = j.id
        WHERE a.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

echo "<h2>Your Job Applications</h2>";
while ($row = $result->fetch_assoc()) {
    echo "<div><strong>Title:</strong> {$row['title']}<br>";
    echo "<strong>Location:</strong> {$row['location']}<br>";
    echo "<strong>Status:</strong> {$row['status']}<br>";
    echo "<strong>Posted:</strong> {$row['posted_date']}</div><hr>";
}
?>
