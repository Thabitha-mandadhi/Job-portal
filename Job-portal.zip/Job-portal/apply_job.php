<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user'])) {
    die("Please login to apply for a job.");
}

$user_email = $_SESSION['user'];

$user_query = $conn->prepare("SELECT id FROM users WHERE email = ?");
$user_query->bind_param("s", $user_email);
$user_query->execute();
$user_result = $user_query->get_result();
$user_data = $user_result->fetch_assoc();
$user_id = $user_data['id'] ?? null;

$job_id = $_GET['job_id'] ?? 0;
if (!$job_id || !$user_id) {
    die("Invalid job or user.");
}

$check = $conn->prepare("SELECT id FROM applications WHERE user_id = ? AND job_id = ?");
$check->bind_param("ii", $user_id, $job_id);
$check->execute();
$check_result = $check->get_result();

if ($check_result->num_rows > 0) {
    echo "✅ You have already applied for this job.";
} else {
    $stmt = $conn->prepare("INSERT INTO applications (user_id, job_id, status) VALUES (?, ?, 'Pending')");
    $stmt->bind_param("ii", $user_id, $job_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "🎉 Successfully applied for the job!";
    } else {
        echo "⚠️ Something went wrong. Please try again.";
    }
}
?>
